package com.Reservation_System;

import java.util.ArrayList;
import java.util.HashMap;

public class SleeperClass extends Seating {
	SleeperClass(HashMap<String, ArrayList<Integer> > bookedSeats) {
		super(bookedSeats);
	}
}
