package com.Reservation_System.Enum;

public enum SeatStatus {
	PB,
	ETE,
	AVL;

}
