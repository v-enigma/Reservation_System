package com.Reservation_System.Enum;

public enum Type {
	UB,
	LB,
	MB,
	SUB,
	SLB;
}
