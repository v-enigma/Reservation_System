package com.Reservation_System.Enum;

public enum BookingStatus {
	CNF,
	RAC,
	WL,
	CAN;
}
