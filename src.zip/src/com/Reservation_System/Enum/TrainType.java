package com.Reservation_System.Enum;

public enum TrainType {
	Express,
	SuperFast;
	
	
}
