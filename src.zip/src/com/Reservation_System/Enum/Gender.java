package com.Reservation_System.Enum;

public enum Gender {
	M,
	F,
	O
}
